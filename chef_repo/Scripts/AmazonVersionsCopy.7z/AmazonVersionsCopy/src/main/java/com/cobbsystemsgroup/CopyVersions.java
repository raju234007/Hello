package com.cobbsystemsgroup;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ListVersionsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.s3.model.S3VersionSummary;
import com.amazonaws.services.s3.model.VersionListing;

public class CopyVersions {

    private static final String BUCKET_NAME = "prodprivatecontent" ; //production bucketname
    private static final String BUCKETNAME_TO_COPY = "uatprivatecontent" ;// uat bucketname

    private static final String AMAZON_ID = "AKIAJOTJRZ2FP2OTBTNQ"; //amazon details production read only and uat write access.
    private static final String AMAZON_SECRET = "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";

    private static final String PRIVATE_CONTENT = "private-content"; // the property ("contentroutingpath") in proform dev properties

    private static final List<String> customerList = Arrays.asList("montgomerycountymd", "mcgov", "cobbsystemsgroup", "mufg", "csgsol", "meta", "earthnetworks", "kaila", "qss"); //Include the customers that have only v2.0.0 folder in job data.
    public static void main(String[] args) {

        AWSCredentials credentials = new BasicAWSCredentials(AMAZON_ID, AMAZON_SECRET);
        AmazonS3 s3client = AmazonS3ClientBuilder.standard().withRegion(Regions.US_EAST_1).withCredentials(new AWSStaticCredentialsProvider(credentials)).build();

        for (String customer : customerList) {
            ListObjectsRequest listObjectRequest = new ListObjectsRequest().withBucketName(BUCKET_NAME)
                    .withPrefix(PRIVATE_CONTENT + "/" + customer) //Specify what ever we want to copy. I guess job data folders are sufficient for the copy.
                    .withDelimiter("/");

            ObjectListing currentListing = s3client.listObjects(listObjectRequest);
            folder(currentListing, s3client);
        }
    }

    private static void folder(ObjectListing currentListing, AmazonS3 s3client) {
        if (currentListing.getCommonPrefixes() != null && !currentListing.getCommonPrefixes().isEmpty()) {
            for (String key : currentListing.getCommonPrefixes()) {
                if ( key.endsWith("/")) {
                    ListObjectsRequest listObjectRequest = new ListObjectsRequest().withBucketName(BUCKET_NAME)
                            .withPrefix(key)
                            .withDelimiter("/");

                    ObjectListing currentListing1 = s3client.listObjects(listObjectRequest);
                    folder(currentListing1, s3client);
                } else {
                    putfile(key, s3client);
                }
            }
        }

        if (currentListing.getObjectSummaries() != null && !currentListing.getObjectSummaries().isEmpty()) {
             for (S3ObjectSummary objectSummary : currentListing.getObjectSummaries()) {
                 putfile(objectSummary.getKey(), s3client);
             }
        }
    }

    private static void putfile(String key, AmazonS3 s3client) {
        ListVersionsRequest listrequest = new ListVersionsRequest()
                .withBucketName(BUCKET_NAME)
                .withPrefix(key)
                .withMaxResults(1000);
        VersionListing versionListing = null;
        do {
            versionListing = s3client.listVersions(listrequest);
            List<S3VersionSummary> s3ObjectSummaries = versionListing.getVersionSummaries();
            Collections.sort(s3ObjectSummaries, new java.util.Comparator<S3VersionSummary>() {
                public int compare(S3VersionSummary o1, S3VersionSummary o2) {
                    return o1.getLastModified().compareTo(o2.getLastModified());
                }
            });
            for (S3VersionSummary versionSummary : versionListing.getVersionSummaries()) {
                try {
                    GetObjectRequest getObjectRequest = new GetObjectRequest(BUCKET_NAME, key);
                    getObjectRequest.setVersionId(versionSummary.getVersionId());
                    S3Object s3Object = s3client.getObject(getObjectRequest);
                    PutObjectRequest putRequest = new PutObjectRequest(BUCKETNAME_TO_COPY, key, s3Object.getObjectContent(), s3Object.getObjectMetadata());
                    s3client.putObject(putRequest);
                    System.out.println("done for the key" + key +"--" + versionSummary.isLatest());
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {

                }
            }
            listrequest.setKeyMarker(versionListing.getNextKeyMarker());
            listrequest.setVersionIdMarker(versionListing.getNextVersionIdMarker());
        } while (versionListing.isTruncated());
    }
}
