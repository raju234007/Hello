package com.cobbsystemsgroup;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class FixReportData {

    private static final String BUCKET_NAME = "mcgov-prod-results" ; //production bucketname

    private static final String AMAZON_ID = "AKIAIAAPSSJ4QFAUM4SA"; //amazon details production read only and uat write access.
    private static final String AMAZON_SECRET = "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";


    public static void main(String[] args) throws IOException {

        AWSCredentials credentials = new BasicAWSCredentials(AMAZON_ID, AMAZON_SECRET);
        AmazonS3 s3client = AmazonS3ClientBuilder.standard().withRegion(Regions.US_EAST_1).withCredentials(new AWSStaticCredentialsProvider(credentials)).build();
        ObjectListing currentListing = s3client.listObjects(BUCKET_NAME);
        do {
            List<S3ObjectSummary> objectSummaries = currentListing.getObjectSummaries();
            for (S3ObjectSummary objectSummary : objectSummaries) {
                try {
                    if (!objectSummary.getKey().endsWith("/")) {
                        GetObjectRequest getObjectRequest = new GetObjectRequest(BUCKET_NAME, objectSummary.getKey());
                        S3Object s3Object = s3client.getObject(getObjectRequest);
                        ObjectMapper mapper = new ObjectMapper();
                        ObjectNode mainnode = (ObjectNode)mapper.readTree(s3Object.getObjectContent());
                        ArrayNode results = (ArrayNode) mainnode.get("results");
                        ArrayNode newResults = JsonNodeFactory.instance.arrayNode();
                        for (JsonNode node : results) {
                            ObjectNode objectNode = ((ObjectNode) node);
                            objectNode.remove("advancedProlangRules");
                            objectNode.remove("mqRuleTrace");
                            ArrayNode newArrayNodes = JsonNodeFactory.instance.arrayNode();
                            ArrayNode questionnairesNode = (ArrayNode) objectNode.get("questionnaires");
                            for (JsonNode questionnaireNode : questionnairesNode) {
                                ObjectNode localNode = (ObjectNode) questionnaireNode;
                                localNode.remove("advancedProlangRules");
                                localNode.remove("mqRuleTrace");
                                newArrayNodes.add(localNode);
                            }
                            objectNode.set("questionnaires", newArrayNodes);
                            newResults.add(objectNode);
                        }
                        mainnode.set("results", newResults);
                        ObjectMetadata meta = new ObjectMetadata();
                        String jsonData = mapper.writeValueAsString(mainnode);
                        meta.setContentLength(jsonData.getBytes().length);
                        PutObjectRequest putRequest = new PutObjectRequest(BUCKET_NAME, objectSummary.getKey(), new ByteArrayInputStream(jsonData.getBytes()), meta);
                        s3client.putObject(putRequest);
                        System.out.println("done for the key" + objectSummary.getKey());
                    }
                } catch(Exception e) {
                    System.out.println("Failed for the key" + objectSummary.getKey());
                }
            }
        } while (currentListing.isTruncated());
        }
}
