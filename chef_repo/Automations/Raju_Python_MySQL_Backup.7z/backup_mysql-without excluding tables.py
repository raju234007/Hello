import boto3
import os, time, sys
import MySQLdb, subprocess
from datetime import datetime
import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEText import MIMEText


path = '/usr/share/backup/'

AWS_ACCESS_KEY_ID = 'AKIAJCLIQNVOOOTYIBHA'
AWS_SECRET_ACCESS_KEY = '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'

foldername = "{:%d-%m-%Y-%H-%M-%S}".format(datetime.now())

# MAKING DIRECTORY WITH TIMESTAMP
subprocess.Popen("mkdir "+path+foldername, shell=True)

dbs = ['accounting','analysis', 'app', 'geo', 'devex', 'oauth', 'simulator']

status = ""
logs = ""

for db in dbs:
    print "DB: "+db

    sub = subprocess.Popen("mysqldump -h 34.234.215.48 -P 3306 -u raju -praju@007 "+db+" > "+path+foldername+"/"+db+".sql", shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

    output, error_output = sub.communicate()
    
    print "Output : "+output
    print "Error : "+error_output

    if ("error" in error_output):
        status = "error"
        logs = logs+"Failed to take dump ("+error_output+")\n"
        break
    
    print "done: "+db


if (status != "error"):
    # CREATING ZIP FILE
    sub = subprocess.Popen("zip -r "+path+foldername+".zip "+path+foldername, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    
    output, error_output = sub.communicate()

    if ("error" in error_output):
        # FAILED TO CREATE ZIP
        logs = logs+"Failed to create ZIP ("+error_output+")\n"
    else:
        # UPLOADING TO S3
        bucket_name = 'rajumanikala.esy.es'
        testfile = foldername+".zip"
        s3 = boto3.resource('s3')
        s3.meta.client.upload_file(testfile, bucket_name, 'backup/'+testfile)    
        # s3.meta.client.upload_file(LOCAL PATH FOR FILE, S3_bucket_name, S3 PATH FOR FILE)   

        
subprocess.Popen("rm -r "+path+foldername, shell=True)

now = time.time()

for file in os.listdir(path):
    file = os.path.join(path, file)
    if os.stat(file).st_mtime < now - 7 * 86400:
        if os.path.isfile(file):
            os.remove(os.path.join(path, file))

        
if (status == "error"):
    # FAILED TO TAKE DUMP
    print "Failed"

    fromaddr = "jbondeve7@gmail.com"
    toaddr = "raju237007@gmail.com"
    msg = MIMEMultipart()
    msg['From'] = fromaddr
    msg['To'] = toaddr
    msg['Subject'] = "DB backup Failure alert"

    body = logs
    msg.attach(MIMEText(body, 'plain'))

    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login(fromaddr, "blidyrrzyqczpxem")
    text = msg.as_string()
    server.sendmail(fromaddr, toaddr, text)
    server.quit()
